"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import Link from "next/link";
import { useRealtimeShifts } from "@/hooks/use-realtime-shifts";
import { ShiftItem, getShiftStaffingMetrics } from "@/components/shared/types";
import { WeekCoverageDashboard } from "@/components/shared/week-coverage-dashboard";

export interface StaffUser {
  id: string;
  staff_code: number;
  full_name: string;
  email: string;
  role: "manager" | "staff";
  profession: "doctor" | "nurse" | "receptionist" | null;
}

export function ManagerDashboard() {
  const [shifts, setShifts] = useState<ShiftItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters & Search State
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<
    "all" | "doctor" | "nurse" | "receptionist"
  >("all");
  const [statusFilter, setStatusFilter] = useState<
    "all" | "full" | "partial" | "empty"
  >("all");

  // Modal / Form state for Create / Edit Shift
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingShiftId, setEditingShiftId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    date: "",
    startTime: "08:00",
    endTime: "16:00",
    doctorsRequired: 1,
    nursesRequired: 2,
    receptionistsRequired: 1,
  });

  // Assignment Modal state
  const [assigningShiftId, setAssigningShiftId] = useState<string | null>(null);
  const [assignUserId, setAssignUserId] = useState("");
  const [assignSearchQuery, setAssignSearchQuery] = useState("");
  const [assignActionMessage, setAssignActionMessage] = useState<string | null>(
    null,
  );

  // Full staff directory, fetched once — powers the "Assign Staff" picker so
  // managers select a real person instead of typing a raw UUID.
  const [staffList, setStaffList] = useState<StaffUser[]>([]);

  const fetchStaffList = useCallback(async () => {
    try {
      const res = await fetch("/api/users");
      if (!res.ok) return; // non-manager or transient error — picker just falls back to empty
      const data = await res.json();
      setStaffList(
        (data.users || []).filter((u: StaffUser) => u.role === "staff"),
      );
    } catch {
      // Silent — the assign form still works via manual entry if this fails.
    }
  }, []);

  useEffect(() => {
    fetchStaffList();
  }, [fetchStaffList]);

  const fetchShifts = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await fetch("/api/shifts");
      if (!res.ok) throw new Error("Failed to load shifts");
      const data = await res.json();
      setShifts(data.shifts || []);

      console.log(
        "[ManagerDashboard] sample shift",
        data[0]?.id,

        "claimsLen",
        data[0]?.claims?.length,

        "status",
        data[0] ? getShiftStaffingMetrics(data[0]).status : null,
      );
    } catch (err: unknown) {
      setError((err as Error).message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchShifts();
  }, [fetchShifts]);

  // Realtime update callback
  useRealtimeShifts(() => {
    fetchShifts();
  });

  // The shift the "Assign Staff" modal is currently open for — drives the
  // modal's header context (date/time/missing roles) automatically.
  const assigningShift = useMemo(
    () => shifts.find((s) => s.id === assigningShiftId) ?? null,
    [shifts, assigningShiftId],
  );

  // People eligible to be picked in the "Assign Staff" modal for the currently
  // open shift: excludes anyone already assigned to it, supports a name/email/
  // staff_code search, and floats still-needed professions to the top.
  const assignablePeople = useMemo(() => {
    if (!assigningShift) return [];

    const alreadyAssignedIds = new Set(
      (assigningShift.claims || []).map((c) => c.user_id),
    );
    const metrics = getShiftStaffingMetrics(assigningShift);
    const stillNeeded: Record<string, boolean> = {
      doctor: metrics.missingDoctors > 0,
      nurse: metrics.missingNurses > 0,
      receptionist: metrics.missingReceptionists > 0,
    };

    const query = assignSearchQuery.trim().toLowerCase();

    return staffList
      .filter((person) => !alreadyAssignedIds.has(person.id))
      .filter((person) => {
        if (!query) return true;
        return (
          person.full_name.toLowerCase().includes(query) ||
          person.email.toLowerCase().includes(query) ||
          String(person.staff_code).includes(query)
        );
      })
      .sort((a, b) => {
        const aNeeded = a.profession ? stillNeeded[a.profession] : false;
        const bNeeded = b.profession ? stillNeeded[b.profession] : false;
        if (aNeeded !== bNeeded) return aNeeded ? -1 : 1;
        return a.full_name.localeCompare(b.full_name);
      });
  }, [assigningShift, staffList, assignSearchQuery, getShiftStaffingMetrics]);

  const filteredShifts = useMemo(() => {
    return shifts.filter((s) => {
      const metrics = getShiftStaffingMetrics(s);

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesDate = s.starts_at.includes(q);
        const matchesId = s.id.toLowerCase().includes(q);
        const matchesMissing = metrics.missingText.toLowerCase().includes(q);
        if (!matchesDate && !matchesId && !matchesMissing) return false;
      }

      // Role filter
      if (roleFilter === "doctor" && s.doctors_required <= 0) return false;
      if (roleFilter === "nurse" && s.nurses_required <= 0) return false;
      if (roleFilter === "receptionist" && s.receptionists_required <= 0)
        return false;

      // Status filter
      if (statusFilter !== "all" && metrics.status !== statusFilter)
        return false;

      return true;
    });
  }, [shifts, searchQuery, roleFilter, statusFilter, getShiftStaffingMetrics]);

  // Shift Create/Edit Handler
  const handleSaveShift = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      const url = editingShiftId
        ? `/api/shifts/${editingShiftId}`
        : "/api/shifts";
      const method = editingShiftId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to save shift");

      setIsModalOpen(false);
      setEditingShiftId(null);
      fetchShifts();
    } catch (err: unknown) {
      setError((err as Error).message);
    }
  };

  // Delete Shift Handler
  const handleDeleteShift = async (id: string) => {
    if (!confirm("Are you sure you want to delete this shift?")) return;
    try {
      const res = await fetch(`/api/shifts/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to delete shift");
      }
      fetchShifts();
    } catch (err: unknown) {
      setError((err as Error).message);
    }
  };

  // Assign Staff Handler
  const handleAssignStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assigningShiftId || !assignUserId.trim()) return;

    setAssignActionMessage(null);
    try {
      const res = await fetch(`/api/shifts/${assigningShiftId}/claim`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: assignUserId.trim() }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to assign staff");

      setAssignUserId("");
      setAssignActionMessage("Staff member assigned successfully!");
      fetchShifts();
    } catch (err: unknown) {
      setAssignActionMessage(`Error: ${(err as Error).message}`);
    }
  };

  // Unassign Staff Handler
  const handleRemoveAssignment = async (shiftId: string, userId: string) => {
    try {
      const res = await fetch(`/api/shifts/${shiftId}/claim?userId=${userId}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to remove staff");
      }

      fetchShifts();
    } catch (err: unknown) {
      setError((err as Error).message);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner & Quick Actions */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            Manager Dashboard
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage clinic shifts, assign staff members, monitor weekly coverage,
            and review CSV import reports.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => {
              setEditingShiftId(null);
              setFormData({
                date: new Date().toISOString().split("T")[0],
                startTime: "08:00",
                endTime: "16:00",
                doctorsRequired: 1,
                nursesRequired: 2,
                receptionistsRequired: 1,
              });
              setIsModalOpen(true);
            }}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm px-4 py-2.5 rounded-lg shadow-sm transition-all"
          >
            + Create New Shift
          </button>
          <Link
            href="/manager/import"
            className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-sm px-4 py-2.5 rounded-lg transition-all border border-slate-300 dark:border-slate-700"
          >
            Import CSV File
          </Link>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-sm font-medium">
          {error}
        </div>
      )}

      {/* Week Coverage Dashboard — shared with the staff view */}
      <WeekCoverageDashboard
        shifts={shifts}
        renderShiftActions={(shift) => (
          <button
            onClick={() => {
              setAssigningShiftId(shift.id);
              setAssignUserId("");
              setAssignSearchQuery("");
              setAssignActionMessage(null);
            }}
            className="bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold px-2.5 py-1.5 rounded transition-colors whitespace-nowrap"
          >
            Assign Staff
          </button>
        )}
      />

      {/* Shift List with Search & Filtering */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold">
              All Clinic Shifts ({filteredShifts.length})
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Search, filter, edit, and assign staff members
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
            {/* Search */}
            <input
              type="text"
              placeholder="Search by date, ID, or missing role..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500 focus:outline-none w-full sm:w-64"
            />

            {/* Role Filter */}
            <select
              value={roleFilter}
              onChange={(e) =>
                setRoleFilter(
                  e.target.value as "all" | "doctor" | "nurse" | "receptionist",
                )
              }
              className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            >
              <option value="all">All Roles</option>
              <option value="doctor">Doctors Required</option>
              <option value="nurse">Nurses Required</option>
              <option value="receptionist">Receptionists Required</option>
            </select>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) =>
                setStatusFilter(
                  e.target.value as "all" | "full" | "partial" | "empty",
                )
              }
              className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="full">Fully Staffed</option>
              <option value="partial">Partially Staffed</option>
              <option value="empty">Empty</option>
            </select>
          </div>
        </div>

        {/* Shift List Table */}
        {isLoading ? (
          <div className="py-12 text-center text-slate-500 text-sm">
            Loading shifts...
          </div>
        ) : filteredShifts.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-sm">
            No shifts match your search and filter criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-800">
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Requirements</th>
                  <th className="py-3 px-4">Coverage Status</th>
                  <th className="py-3 px-4">Assigned Staff</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {filteredShifts.map((shift) => {
                  const metrics = getShiftStaffingMetrics(shift);
                  const startDate = new Date(shift.starts_at);
                  const endDate = new Date(shift.ends_at);

                  const isOvernight =
                    endDate.getUTCDate() !== startDate.getUTCDate();
                  const dateStr = startDate.toISOString().split("T")[0];
                  const startStr = startDate.toISOString().substring(11, 16);
                  const endStr = endDate.toISOString().substring(11, 16);

                  return (
                    <tr
                      key={shift.id}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors"
                    >
                      <td className="py-4 px-4 font-medium">
                        <div>{dateStr}</div>
                        <div className="text-xs text-slate-500">
                          {startStr} – {endStr} {isOvernight ? "(+1 day)" : ""}
                        </div>
                      </td>

                      <td className="py-4 px-4 text-xs space-y-1">
                        <div>
                          Doctors:{" "}
                          <span className="font-semibold">
                            {shift.doctors_required}
                          </span>
                        </div>
                        <div>
                          Nurses:{" "}
                          <span className="font-semibold">
                            {shift.nurses_required}
                          </span>
                        </div>
                        <div>
                          Receptionists:{" "}
                          <span className="font-semibold">
                            {shift.receptionists_required}
                          </span>
                        </div>
                      </td>

                      <td className="py-4 px-4">
                        <span
                          className={`inline-block px-2.5 py-1 text-xs font-bold uppercase rounded-full tracking-wide ${
                            metrics.status === "full"
                              ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800"
                              : metrics.status === "partial"
                                ? "bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300 border border-amber-300 dark:border-amber-800"
                                : "bg-rose-100 text-rose-800 dark:bg-rose-900/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800"
                          }`}
                        >
                          {metrics.status}
                        </span>
                        <div className="text-xs text-slate-500 mt-1 font-medium">
                          {metrics.missingText}
                        </div>
                      </td>

                      <td className="py-4 px-4 text-xs">
                        {shift.claims && shift.claims.length > 0 ? (
                          <div className="space-y-1">
                            {shift.claims.map((claim) => (
                              <div
                                key={claim.id}
                                className="flex items-center justify-between gap-2 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded"
                              >
                                <span>
                                  {claim.user?.full_name || claim.user_id} (
                                  {claim.user?.profession || "staff"})
                                </span>
                                <button
                                  onClick={() =>
                                    handleRemoveAssignment(
                                      shift.id,
                                      claim.user_id,
                                    )
                                  }
                                  className="text-rose-600 hover:text-rose-700 font-bold ml-1"
                                  title="Remove assignment"
                                >
                                  &times;
                                </button>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">
                            None assigned
                          </span>
                        )}
                      </td>

                      <td className="py-4 px-4 text-right space-x-2 whitespace-nowrap">
                        <button
                          onClick={() => {
                            setAssigningShiftId(shift.id);
                            setAssignUserId("");
                            setAssignSearchQuery("");
                            setAssignActionMessage(null);
                          }}
                          className="bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold px-2.5 py-1.5 rounded transition-colors"
                        >
                          Assign Staff
                        </button>

                        <button
                          onClick={() => {
                            setEditingShiftId(shift.id);
                            setFormData({
                              date: dateStr,
                              startTime: startStr,
                              endTime: endStr,
                              doctorsRequired: shift.doctors_required,
                              nursesRequired: shift.nurses_required,
                              receptionistsRequired:
                                shift.receptionists_required,
                            });
                            setIsModalOpen(true);
                          }}
                          className="bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 text-xs font-semibold px-2.5 py-1.5 rounded transition-colors"
                        >
                          Edit
                        </button>

                        <button
                          onClick={() => handleDeleteShift(shift.id)}
                          className="bg-rose-50 hover:bg-rose-100 dark:bg-rose-950 dark:hover:bg-rose-900 text-rose-700 dark:text-rose-300 text-xs font-semibold px-2.5 py-1.5 rounded transition-colors"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create / Edit Shift Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 w-full max-w-md shadow-2xl">
            <h2 className="text-xl font-bold mb-4">
              {editingShiftId ? "Edit Shift" : "Create New Shift"}
            </h2>

            <form onSubmit={handleSaveShift} className="space-y-4 text-sm">
              <div>
                <label className="block font-semibold mb-1">Shift Date</label>
                <input
                  type="date"
                  required
                  value={formData.date}
                  onChange={(e) =>
                    setFormData({ ...formData, date: e.target.value })
                  }
                  className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold mb-1">Start Time</label>
                  <input
                    type="time"
                    required
                    value={formData.startTime}
                    onChange={(e) =>
                      setFormData({ ...formData, startTime: e.target.value })
                    }
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">End Time</label>
                  <input
                    type="time"
                    required
                    value={formData.endTime}
                    onChange={(e) =>
                      setFormData({ ...formData, endTime: e.target.value })
                    }
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-xs">
                    Doctors
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.doctorsRequired}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        doctorsRequired: parseInt(e.target.value, 10) || 0,
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-xs">
                    Nurses
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.nursesRequired}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        nursesRequired: parseInt(e.target.value, 10) || 0,
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-xs">
                    Receptionists
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.receptionistsRequired}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        receptionistsRequired:
                          parseInt(e.target.value, 10) || 0,
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-slate-600 dark:text-slate-400 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-sm"
                >
                  Save Shift
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Assign Staff Modal */}
      {assigningShiftId && assigningShift && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 w-full max-w-md shadow-2xl">
            <h2 className="text-xl font-bold mb-1">Assign Staff Member</h2>

            {/* Auto-populated shift context — no need to look up the shift elsewhere */}
            <div className="mb-4 p-3 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs">
              <div className="font-semibold">
                {new Date(assigningShift.starts_at).toISOString().split("T")[0]}
                {"  "}
                {new Date(assigningShift.starts_at)
                  .toISOString()
                  .substring(11, 16)}{" "}
                –{" "}
                {new Date(assigningShift.ends_at)
                  .toISOString()
                  .substring(11, 16)}
              </div>
              <div className="text-slate-500 dark:text-slate-400 mt-0.5">
                {getShiftStaffingMetrics(assigningShift).missingText}
              </div>
            </div>

            {assignActionMessage && (
              <div
                className={`mb-4 p-3 rounded-lg text-xs font-medium ${
                  assignActionMessage.startsWith("Error")
                    ? "bg-rose-50 text-rose-700"
                    : "bg-emerald-50 text-emerald-700"
                }`}
              >
                {assignActionMessage}
              </div>
            )}

            <form onSubmit={handleAssignStaff} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1">
                  Search staff
                </label>
                <input
                  type="text"
                  placeholder="Search by name, email, or staff code"
                  value={assignSearchQuery}
                  onChange={(e) => setAssignSearchQuery(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm mb-2"
                />

                <label className="block text-xs font-semibold mb-1">
                  Select staff member
                </label>
                <select
                  required
                  value={assignUserId}
                  onChange={(e) => setAssignUserId(e.target.value)}
                  size={Math.min(8, Math.max(4, assignablePeople.length))}
                  className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm"
                >
                  {assignablePeople.length === 0 && (
                    <option value="" disabled>
                      {staffList.length === 0
                        ? "Loading staff…"
                        : "No matching staff found"}
                    </option>
                  )}
                  {assignablePeople.map((person) => (
                    <option key={person.id} value={person.id}>
                      {person.full_name} — {person.profession ?? "staff"} (#
                      {person.staff_code})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setAssigningShiftId(null)}
                  className="px-4 py-2 text-slate-600 dark:text-slate-400 font-semibold text-sm"
                >
                  Close
                </button>
                <button
                  type="submit"
                  disabled={!assignUserId}
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg shadow-sm text-sm disabled:opacity-50"
                >
                  Assign Staff
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
